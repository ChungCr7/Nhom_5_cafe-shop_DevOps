export default function StatusImage() {
  return (
    <img src="/images/success.png" alt="Suceess Vector" className="w-1/2 sm:w-1/4" />
  );
}
