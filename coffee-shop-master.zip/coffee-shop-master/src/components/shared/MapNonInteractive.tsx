import MapComponent from './MapComponent';

const MapNonInteractive = () => {
  return <MapComponent interactive={false} />;
};

export default MapNonInteractive;
