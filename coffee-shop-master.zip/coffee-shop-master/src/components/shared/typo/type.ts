export interface TitleProps {
  children: string;
  className?: string;
}
