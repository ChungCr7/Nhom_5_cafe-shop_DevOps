import { CoffeeProduct } from '@/types';

export interface ProductCardProps {
  coffee: CoffeeProduct;
}
